# Solution for model Obj
# Objective value = 80
x0 0
x1 0
x2 10
x3 10
x4 0
C0 0
C1 0
C2 0
C3 0
C4 0
